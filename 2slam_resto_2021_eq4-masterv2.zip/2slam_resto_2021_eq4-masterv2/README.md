# PhpProjectResto2021

AP 2SLAM - projet du premier semestre
Contexte
site r3st0.fr,site de critique (Cf. lafourchette, tripadvisor, etc.)
https://www.reseaucerta.org/decouverte-mvc-et-acces-aux-donnees-dans-une-application-web-en-php
