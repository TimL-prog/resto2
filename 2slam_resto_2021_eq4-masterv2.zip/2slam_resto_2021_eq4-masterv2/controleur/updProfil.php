<?php

use modele\dao\Bdd;
use modele\dao\UtilisateurDAO;
use modele\dao\TypeCuisineDAO;
use modele\dao\AimerDAO;
use modele\dao\PrefererDAO;

/**
 * Contrôleur updProfil
 * Page d'affichage des caractéristiques d'un utilisateur
 * 
 * Vues contrôlées : vueUpdProfil, vueAuthentification.php
 * 
 */
Bdd::connecter();

// creation du menu burger
$admin=utilisateurDAO::getAdminById($_SESSION['idU']);


if ($admin != 1){
    $menuBurger = array();
    $menuBurger[] = Array("url"=>"./?action=profil","label"=>"Consulter mon profil");
    $menuBurger[] = Array("url"=>"./?action=updProfil","label"=>"Modifier mon profil");
}else{
    $menuBurger = array();
    $menuBurger[] = Array("url"=>"./?action=profil","label"=>"Consulter mon profil");
    $menuBurger[] = Array("url"=>"./?action=updProfil","label"=>"Modifier mon profil");
    $menuBurger[] = Array("url"=>"./?action=gererLesUtilisateurs","label"=>"Gérer les utilisateurs");
    $menuBurger[] = Array("url"=>"./?action=gererLesRestaurants","label"=>"Gérer les restaurants");
    $menuBurger[] = Array("url"=>"./?action=updTypeCuisine","label"=>"Gérer les types de cuisine");
}
// Initialisations 
$titre = "Mon profil";

// Si un utilisateur est connecté
if (isLoggedOn()) {
    // récupérer son identité
    $idU = getIdULoggedOn();
    $util = UtilisateurDAO::getOneById($idU);

    // Mise à jour de l'objet Utilisateur $util en fonction des saisies
    // Nouveau pseudo
    $pseudoU = "";
    if (isset($_POST["pseudoU"])) {
        $pseudoU = $_POST["pseudoU"];
        if ($pseudoU != "") {
            $util->setPseudoU($pseudoU);
            UtilisateurDAO::update($util);
        }
    }

    // Nouveau mot de passe
    $mdpU = "";
    if (isset($_POST["mdpU"]) && isset($_POST["mdpU2"])) {
        if ($_POST["mdpU"] != "") {
            if (($_POST["mdpU"] == $_POST["mdpU2"])) {
                $mdpU = $_POST["mdpU"];
                UtilisateurDAO::updateMdp($idU, $mdpU);
                logout();
            } else {
                ajouterMessage("Mise à jour du profil : erreur de saisie du mot de passe");
            }
        }
    }

    // Restaurants à supprimer de la liste des restaurants aimés
    if (isset($_POST["lstidR"])) {
        $lstidR = $_POST["lstidR"];
        for ($i = 0; $i < count($lstidR); $i++) {
            AimerDAO::delete($idU, $lstidR[$i]);
        }
    }
    // Types de cuisine à ajouter à la liste des types de cuisine préférés
    if (isset($_POST["addLstidTC"])) {
        $addLstidTC = $_POST["addLstidTC"];
        for ($i = 0; $i < count($addLstidTC); $i++) {
            PrefererDAO::insert($idU, $addLstidTC[$i]);
        }
    }

    // Types de cuisine à supprimer de liste des types de cuisine préférés
    if (isset($_POST["delLstidTC"])) {
        $delLstidTC = $_POST["delLstidTC"];
        for ($i = 0; $i < count($delLstidTC); $i++) {
            PrefererDAO::delete($idU, $delLstidTC[$i]);
        }
    }

// Si on a changé le mot de passe, il faut se reconnecter
    if (!isLoggedOn()) {
        // Construction de la vue
        require_once "$racine/vue/entete.html.php";
        require_once "$racine/vue/vueAuthentification.php";
        require_once "$racine/vue/pied.html.php";
    } else {
        // Sinon, on revient sur le formulaire
        // Recharger les données
        $util = UtilisateurDAO::getOneById($idU);
        $mesRestosAimes = $util->getLesRestosAimes();
        $mesTypeCuisinePreferes = $util->getLesTypesCuisinePreferes();
        $lesAutresTypesCuisine = TypeCuisineDAO::getAllNonPreferesByIdU($idU);

        // Construction de la vue
        require_once "$racine/vue/entete.html.php";
        require_once "$racine/vue/vueUpdProfil.php";
        require_once "$racine/vue/pied.html.php";
    }
} else {
    // Si aucun utilisateur n'est connecté
    // Construction de la vue vide
    ajouterMessage("Update profil : aucun utilisateur n'est connecté");
    require_once "$racine/vue/entete.html.php";
    require_once "$racine/vue/pied.html.php";
}
?>